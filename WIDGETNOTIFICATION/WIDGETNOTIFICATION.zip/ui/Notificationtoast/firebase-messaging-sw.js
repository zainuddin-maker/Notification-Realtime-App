/*
	File ini di letakkan di root/

*/
// Give the service worker access to Firebase Messaging.
// Note that you can only use Firebase Messaging here, other Firebase libraries
// are not available in the service worker.
// importScripts('https://www.gstatic.com/firebasejs/7.8.0/firebase-app.js');
// importScripts('https://www.gstatic.com/firebasejs/7.8.0/firebase-messaging.js');

importScripts('https://www.gstatic.com/firebasejs/3.9.0/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/3.9.0/firebase-messaging.js');

// Initialize the Firebase app in the service worker by passing in the
// messagingSenderId.
firebase.initializeApp({
                //    apiKey: "AIzaSyBQ4YPnixyJmT8wdAU4ycTfF88GSij69bM",
                //     authDomain: "test-notification-app-e1507.firebaseapp.com",
                //     projectId: "test-notification-app-e1507",
                //     storageBucket: "test-notification-app-e1507.appspot.com",
                    messagingSenderId: "1007562721667",
                    // appId: "1:1007562721667:web:7982841128dc6dbf35ceb6",
});

// Retrieve an instance of Firebase Messaging so that it can handle background
// messages.
const messaging = firebase.messaging();

// messaging.setBackgroundMessageHandler(function (payload) {
//     console.log(
//         "[firebase-messaging-sw.js] Received background message ",
//         payload
//     );
//     // Customize notification here
//     const notificationTitle = "Background Message Title";
//     const notificationOptions = {
//         body: "Background Message body.",
//         icon: "http://localhost/addOns/open-my-page-button/icons/page-48.png",
//     };

//     // return self.registration.showNotification(
//     //     notificationTitle,
//     //     notificationOptions
//     // );
// });
